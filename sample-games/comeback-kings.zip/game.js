// Comeback Kings: a whole-class speaking game in two rounds.
const twisters = [
  "Red lorry, yellow lorry.",
  "She sells seashells by the seashore.",
  "Unique New York, you know you need unique New York.",
];

const roastCards = [
  "Card 1: Your excuse for missing homework is so old it has a beard.",
  "Card 2: You dance like a robot that forgot its batteries.",
  "Card 3: Your jokes are so slow they need a map to find the punchline.",
  "Card 4: You're so heavy the scale asks you to step off.",
  "Card 5: Your handwriting looks like a spider went ice skating.",
  "Card 6: You take so long to answer, the question retired.",
  "Card 7: Your face is so ugly the mirror cracked when you smiled.",
  "Card 8: Your backpack is so messy it has its own weather.",
];

const players = [];
let twister = 0;

function show(id) {
  for (const s of ["join", "warmup", "roast", "board"]) {
    document.getElementById(s).hidden = s !== id;
  }
}

document.getElementById("join-btn").addEventListener("click", () => {
  const firstName = document.getElementById("first-name").value;
  const school = document.getElementById("school-name").value;
  players.push({ firstName, school, points: 0 });
  show("warmup");
  document.getElementById("twister").textContent = twisters[0];
});

document.getElementById("next-twister").addEventListener("click", () => {
  twister += 1;
  if (twister >= twisters.length) {
    show("roast");
    return;
  }
  document.getElementById("twister").textContent = twisters[twister];
});

document.getElementById("draw").addEventListener("click", () => {
  const card = roastCards[Math.floor(Math.random() * roastCards.length)];
  document.getElementById("card").textContent = card;
});
