// Haggle Hero: three short negotiation levels for partners.
const levels = [
  {
    title: "Level 1: The fruit stand",
    lines: [
      ["Merchant", "Fresh apples! Three for five coins."],
      ["Buyer", "That seems a bit high. Would you take four coins?"],
      ["Merchant", "Four coins it is, if you buy six."],
    ],
  },
  {
    title: "Level 2: The bike shop",
    lines: [
      ["Merchant", "This bike costs forty coins."],
      ["Buyer", "I only have thirty. Can you add a helmet if I pay thirty-five?"],
      ["Merchant", "Deal. Everyone wins when we both give a little."],
    ],
  },
  {
    title: "Level 3: The shrewd merchant",
    lines: [
      [
        "Merchant",
        "Notwithstanding your ostensibly generous proposition, I must emphasize that this artisanal lantern's provenance and meticulous craftsmanship are commensurate with a considerably higher valuation.",
      ],
      ["Buyer", "What if I pay twenty and tell my friends about your shop?"],
      [
        "Merchant",
        "Your counterproposal, while not entirely unreasonable, necessitates a reciprocal concession; consequently, I would acquiesce at twenty-four coins, contingent upon an expeditious transaction.",
      ],
    ],
  },
];

let level = 0;
let line = 0;

function show(id) {
  for (const s of ["start", "scene", "end"]) {
    document.getElementById(s).hidden = s !== id;
  }
}

function render() {
  const current = levels[level];
  document.getElementById("level-title").textContent = current.title;
  const [speaker, text] = current.lines[line];
  document.getElementById("speaker").textContent = speaker + ":";
  document.getElementById("text").textContent = text;
}

document.getElementById("play").addEventListener("click", () => {
  level = 0;
  line = 0;
  show("scene");
  render();
});

document.getElementById("next").addEventListener("click", () => {
  line += 1;
  if (line >= levels[level].lines.length) {
    level += 1;
    line = 0;
  }
  if (level >= levels.length) {
    show("end");
    return;
  }
  render();
});

document.getElementById("again").addEventListener("click", () => show("start"));
